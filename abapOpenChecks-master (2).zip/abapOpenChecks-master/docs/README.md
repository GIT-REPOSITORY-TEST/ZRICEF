Generated documentation, read at http://docs.abapopenchecks.org
